
%% CLasso
clc
clear

num = 100;
noise_level=0.01;
x1=rand(num,10)*10 + 100;
x2=rand(num,10)*10;

y1 = zeros(size(x1,1),1)+1;
y2 = zeros(size(x2,1),1)-1;

Data = [x1;x2];
trainLabel = [y1;y2];

testdata = [x1(1:10,:); x2(1:10,:)];
trainData=Data;


opts = [];
labelPer = 1;
gg = 1;
N = size(trainData,1);
D = size(trainData,2);
class_num = size(unique(trainLabel),1);
opts.labelIndex = 1:N;
P = zeros(1,size(trainData,1));
P(opts.labelIndex) = 1; % index matrix for labeled data and unlabeled data 
opts.P = diag(P);  

constrNum = 20;
opts.num_constraints_M = constrNum ;
opts.num_constraints_C = constrNum ;
          
L_M=[];
L_C=[];
size_m=opts.num_constraints_M; % number of must-link constraint
size_c=opts.num_constraints_C; % number of cannot-link constraint  

C1 = zeros(N, N);
M1= zeros(N, N);     
[M,C]=gen_constraints(trainData,trainLabel,size_m,size_c);
for i=1:size_m,
    M1(M(i,1),M(i,2))=1;
    M1(M(i,2),M(i,1))=1;
end
for i=1:size_c,
    C1(C(i,1),C(i,2))=1;
    C1(C(i,2),C(i,1))=1;
end         
 
L_C = diag(sum(C1))- C1;   
L_M = diag(sum(M1))- M1;
               
% Initialization             
opts.init=2;        % starting from a zero point
% termination criterion
opts.tFlag=5;       % run .maxIter iterations
opts.maxIter=50;   % maximum number of iterations
% normalization
opts.nFlag=0;       % without normalization regularization
opts.rFlag=0;       % the input parameter 'rho' is a ratio in (0, 1)
opts.rsL2=0;     % the squared two norm term
opts.mFlag=0;       % treating it as compositive function 
opts.lFlag=0;       % Nemirovski's line search

opts.lambda1 = 0.5; % L1-norm
opts.lambda2 = 0.1;  % must-link regularization
opts.lambda3 = 0.001; % cannot-link regularization  
               
[classoW,funVal]=CLasso(trainData, trainLabel, opts,L_M,L_C);
 
aa=1;

